Getting Started with Your React App
This project was initialized using Create React App.

Available Scripts
In the project directory, you can use the following commands:

npm start: Starts the development server.
Open http://localhost:3000 to view the app in your browser.
The page will automatically reload if you make edits, and lint errors will be shown in the console.

npm test: Launches the test runner in interactive watch mode.
Refer to the testing section for more details.

npm run build: Generates a production-ready build in the build folder.
It optimizes the build for optimal performance, bundling React in production mode and minifying the files.
The build is minified, and file names include hashes for cache busting.
Your application is now ready for deployment!
Check the deployment section for further instructions.

npm run eject: Warning: This operation is irreversible!
If you're dissatisfied with the default build tool and configuration, you can eject at any time.
This command removes the single build dependency from your project and copies all configuration files and transitive dependencies (webpack, Babel, ESLint, etc.) directly into your project.
You'll have complete control over these files and can modify them as needed.
All commands except eject will continue to function, pointing to the copied scripts.

Ejecting isn't obligatory. The default feature set is suitable for small to medium deployments, and you're not obligated to use this feature.
However, it's available if you require additional customization.

Further Resources
For more information, consult the Create React App documentation.
To learn more about React, consult the React documentation.
Additional Topics
Code Splitting: Details on code splitting are now located here.
Analyzing Bundle Size: Instructions on analyzing bundle size have been relocated here.
Progressive Web App Development: Guidance on creating a Progressive Web App can be found here.
Advanced Configuration: Additional configuration options are available here.
Deployment: Instructions for deployment are now available on this page.
Build Minification Issues: Troubleshooting for build minification issues is now located here.
<h1> NISHIMWE Umutoniwase Divine </h1>